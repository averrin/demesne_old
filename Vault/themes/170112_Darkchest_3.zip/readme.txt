
This resource has been created by Mateusz Przegi�tka for www.psdchest.com


TERMS OF USE:

All resources made available on PSDchest.com, including but not limited to, icons, images, 
brushes, shapes, layer styles, layered PSD�s, patterns, textures, web elements and themes are free for
use in both personal and commercial projects.

You may freely use our resources, without restriction, in
software programs, web templates and other materials intended for sale or distribution. No attribution
or backlinks are required, but any form of spreading the word is always appreciated!

You are not
permitted to make the resources found on PSDchest.com available for distribution elsewhere without
prior consent.




Mateusz Przegi�tka for PSDchest.com


www.psdchest.com
